from django.db import models
from django.contrib.auth.models import BaseUserManager, AbstractBaseUser, PermissionsMixin
from django.core.exceptions import ValidationError


class CustomUserManager(BaseUserManager):   
    def create_user(self, username, email, balance,  password=None):
        if not email:
            raise ValueError("Email is required")
        if not username:
            raise ValueError("Username is required")
        if not balance:
            raise ValueError("Balance is required")
        if int(balance) < 0:
            raise ValueError("Balance can't be NEGATIVE")
        
        user = self.model(
            username=username,
            email=self.normalize_email(email),
            balance = balance
        )
        user.set_password(password)
        user.save(using=self._db)

        return user
    
    def create_superuser(self, username, email, password=None):
        if not email:
            raise ValueError("Email is required")
        if not username:
            raise ValueError("Username is required")
        user = self.model(
            username=username,
            email=self.normalize_email(email),
        )
        user.set_password(password)
        user.is_admin = True
        user.is_staff = True
        user.is_superuser = True
        user.save(using=self._db)

        return user
    
    def create_transaction(self, transaction_id, from_username , to_username , amount):
        if not transaction_id:
            raise ValueError("Transaction_ID is required")
        if not from_username:
            raise ValueError("Username is required")
        if not to_username:
            raise ValueError("Username is required")
        if not amount:
            raise ValueError("Amount is required")
        if int(amount) < 0:
            raise ValueError("Amount can't be negative")
        transaction = self.model(
            transaction_id = transaction_id,
            to_username = CustomUser(username = to_username),
            from_username = CustomUser(username = from_username),
            amount=amount
        )
        transaction.save(using=self._db)
        return transaction
       
    
    
    
class CustomUser(AbstractBaseUser, PermissionsMixin):
    email = models.EmailField(max_length=100, unique=True)
    username = models.CharField(max_length=50, primary_key=True)
    balance = models.DecimalField(max_digits=12, decimal_places=2)

    is_active = models.BooleanField(default=True)
    is_admin = models.BooleanField(default=False)
    is_staff = models.BooleanField(default=False)
    is_superuser = models.BooleanField(default=False)

    USERNAME_FIELD = 'username'
    REQUIRED_FIELDS = ['email']

    objects = CustomUserManager()

    def __str__(self):
        return self.username
    
    
    def save(self, *args, **kwargs):
        self.validate_unique()
        super().save(*args, **kwargs)
        
class Transaction(models.Model):
    from_username = models.ForeignKey(CustomUser, on_delete=models.CASCADE, related_name='sender_transactions')
    to_username = models.ForeignKey(CustomUser, on_delete=models.CASCADE, related_name='receiver_transactions')
    transaction_id = models.IntegerField(primary_key=True)
    amount = models.DecimalField(max_digits=15, decimal_places=2)
      
    
    objects = CustomUserManager()
    
    def __str__(self):
        return self.transaction_id
    
    
    
    
    
    

        


