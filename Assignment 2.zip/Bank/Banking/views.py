from django.shortcuts import render
from rest_framework.views import APIView
from rest_framework.response import Response

from .models import CustomUser , Transaction , CustomUserManager
from .serializers import CustomUserSerializer , TransactionSerializer

class CustomUserList(APIView):
    queryset = CustomUser.objects.all()
    serializer_class = CustomUserSerializer

    def get(self, request):
        users = CustomUser.objects.all()
        serializer = CustomUserSerializer(users, many=True)
        return Response(serializer.data)
    
    def post(self, request):
        username = request.data.get('username')
        email = request.data.get('email')
        password = request.data.get('password')
        balance = request.data.get('balance')
        user = CustomUser.objects.create_user(username, email, balance, password)

        serializer = CustomUserSerializer(user)
        return Response(serializer.data)
    
    def delete(self,request):
        users = CustomUser.objects.all()
        users.delete()
        return Response("DELETED")


class CustomUserDetailView(APIView):
    def get_queryset(self):
        return CustomUser.objects.all()

    def get(self, request, pk):
        user = CustomUser.objects.get(username=pk)
        serializer = CustomUserSerializer(user)
        return Response(serializer.data)
    
    def put(self, request, pk):
        user = CustomUser.objects.get(username=pk)
        serializer = CustomUserSerializer(user)
        email = request.data.get('email')
        password = request.data.get('password')
        balance = request.data.get('balance')
        serializer = CustomUserSerializer(user, email, password, balance)
        
    def delete(self, request, pk):
        user = CustomUser.objects.get(username=pk)
        user.delete()
        return Response("DELETED")

class TransactionList(APIView):
    queryset = Transaction.objects.all()
    serializer_class = TransactionSerializer

    def get(self, request):
        transaction  = Transaction.objects.all()
        serializer = TransactionSerializer(transaction, many=True)
        return Response(serializer.data)
    
    def post(self, request):
        from_username = request.data.get('from_username')
        to_username = request.data.get('to_username')
        transaction_id = request.data.get('transaction_id')
        amount = request.data.get('amount')
        transaction = Transaction.objects.create_transaction(transaction_id, from_username, to_username, amount)
        serializer = TransactionSerializer(transaction)
        user1 = CustomUser.objects.get(username=from_username)
        user2 = CustomUser.objects.get(username=to_username)
        if int(user1.balance) >= int(amount):
            user1.balance -= int(amount)
            user2.balance += int(amount)
            user1.save()
            user2.save()
            return Response(serializer.data)
        else:
            return Response("INSUFFICIENT FUNDS FOR TRANSACTION")
    

class TransactionDetailView(APIView):
    def get(self, request, pk):
        user = Transaction.objects.get(username=pk)
        serializer = TransactionSerializer(user)
        return Response(serializer.data)

   
    

    
    
    


 
    
    
   
