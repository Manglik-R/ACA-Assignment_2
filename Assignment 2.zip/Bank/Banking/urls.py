from django.urls import path
from . import views

urlpatterns = [
    path("users/", views.CustomUserList.as_view(), name="users"),
    path("users/<str:pk>/", views.CustomUserDetailView.as_view(), name="user-detail"),  
    path('transactions/', views.TransactionList.as_view(), name="transactions"),
    path('transactions/<int:pk>/', views.TransactionDetailView.as_view(), name="transactions-detail"),
]
