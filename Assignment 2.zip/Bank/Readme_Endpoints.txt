Endpoint ---- What it does

1- http://localhost:8000/Banking/users/ ----- GET request to view all registered users , POST request to create/register a new user , DELETE request to delete all users
2- http://localhost:8000/Banking/users/username ----- GET request to view a registered user using a primary key , DELETE request to delete a user using a primary key , PUT request to update user details for a given user
3- http://localhost:8000/Banking/transactions/ ----- GET request to view all transactions , POST request to create transactions
4- http://localhost:8000/Banking/transactions/transaction_id ----- GET request to view a particular transaction using a transaction id


